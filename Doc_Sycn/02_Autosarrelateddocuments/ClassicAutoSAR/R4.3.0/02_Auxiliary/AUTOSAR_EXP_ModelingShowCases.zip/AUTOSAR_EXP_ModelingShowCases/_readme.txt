Document Title:                 Modeling Show Cases (Supplement for the Technical Report)
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 790
Document Classification:        Auxiliary
Document Status:                Final
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       4.3.0
Date:                           2016-11-30

This zip file contains supplementary material for the technical report
"Modeling Show Cases" (DocID: 789), e.g. ARXML-Files, A2L-Files, etc.
The folder structure resembles the structure of the technical report.
For more information on the content of this zip file, please refer to
this report. 


In addition, this archive contains the following in addition:

_readme.txt       This file
_disclaimer.txt   Verbatim copy of the AUTOSAR Disclaimer
