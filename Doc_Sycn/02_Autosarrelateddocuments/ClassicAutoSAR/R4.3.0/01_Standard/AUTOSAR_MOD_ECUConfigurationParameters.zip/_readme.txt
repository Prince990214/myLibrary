Document Title:                 Specification of ECU Configuration Parameters (XML)
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 289
Document Classification:        Standard
Document Status:                Final
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       4.3.0
Date:                           2016-11-30
